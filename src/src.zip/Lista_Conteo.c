#include <stdio.h>
#include "miLista.h"

extern int Lista_Conteo(ListaEnlazada *lista){
	return lista->numeroElementos;
}
