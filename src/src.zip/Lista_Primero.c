#include <stdio.h>
#include "miLista.h"

extern ElementoLista *Lista_Primero(ListaEnlazada *lista){
	if(lista->numeroElementos==0){
		printf("Hola");
		return NULL;
	}else{
		ElementoLista *elemento;
		elemento=(lista->ancla).siguiente;
		printf("Hola");
		return elemento;
	}
}
